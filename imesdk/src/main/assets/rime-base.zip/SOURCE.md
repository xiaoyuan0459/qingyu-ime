# 对应源码

- 词库源：白霜拼音（轻语版） https://github.com/gaboolic/rime-frost/tree/96278d87bf29403dd16ac854e71c496ab6ee5e71
- rime-essay: https://github.com/rime/rime-essay/tree/e2652ea18609a879eae3e87db5d25b7fbc1a4f93 （essay.txt SHA-256: `e62fb950175ff5c33bff4480a8d96f7b4fa83e9a9420d32a596877aa61257ead`）
- rime-stroke（五笔画，LGPL-3.0-or-later）: https://github.com/rime/rime-stroke/tree/1e8fff9b9494ddec23b0cbc526bcfd8171a6fd48 （stroke.dict.yaml SHA-256: `b3e93dce89c185f45c3d6e189b86b3a8626913352cc85e1094c786579a665791`，码表归属见 `AUTHORS.rime-stroke`）
- 方案装配清单：本仓库 `imesdk/rime-src/`（词典装配表）+ `imesdk/src/main/assets/rime/build/`（各 `*.schema.yaml` 与 `default.yaml`）
- 构建脚本：本仓库 `tools/build-rime-pack.py`（装配源树并调用 `qingyu_deployer` 编译）
- OpenCC 仅用于 emoji：https://github.com/BYVoid/OpenCC
- 原生繁体词条：CC-CEDICT，固定来源、哈希、归属和修改说明见 native-forms.json / AUTHORS.cc-cedict / LICENSE.cc-cedict；词频适配层 GPL-3.0-only
- 只读联想索引：tools/rime_associations.py，按本轮实际导入分表生成，QYAS0001 格式
