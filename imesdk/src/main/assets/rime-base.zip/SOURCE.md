# 对应源码

- 词库源：雾凇拼音（轻语版） https://github.com/iDvel/rime-ice/tree/9e66b0729083b37d217312294f6d516c8d7234be
- rime-essay: https://github.com/rime/rime-essay/tree/e2652ea18609a879eae3e87db5d25b7fbc1a4f93 （essay.txt SHA-256: `e62fb950175ff5c33bff4480a8d96f7b4fa83e9a9420d32a596877aa61257ead`）
- rime-stroke（五笔画，LGPL-3.0-or-later）: https://github.com/rime/rime-stroke/tree/1e8fff9b9494ddec23b0cbc526bcfd8171a6fd48 （stroke.dict.yaml SHA-256: `b3e93dce89c185f45c3d6e189b86b3a8626913352cc85e1094c786579a665791`，码表归属见 `AUTHORS.rime-stroke`）
- 方案装配清单：本仓库 `imesdk/rime-src/`（词典装配表）+ `imesdk/src/main/assets/rime/build/`（各 `*.schema.yaml` 与 `default.yaml`）
- 构建脚本：本仓库 `tools/build-rime-pack.py`（装配源树并调用 `qingyu_deployer` 编译）
- OpenCC 简繁转换表：https://github.com/BYVoid/OpenCC
